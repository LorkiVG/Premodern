<?php




return [
  'max_skins' => 5,
];










?>