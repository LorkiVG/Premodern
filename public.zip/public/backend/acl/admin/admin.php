<?php 
return [
	'all' => [
		
	],
	'authorize' => [
		//
	],
	'guest' => [
		
	],
	'admin' => [
		'login'
	],
	'admin_active' => [
		'index',
		'logout',
		'statistic',
		'players',
		'others',
		'editPlayer',
		'getSkinByPlayer'
	]
];
?>