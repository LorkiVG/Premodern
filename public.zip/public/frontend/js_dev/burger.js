const burger = document.querySelector(".header__burger");
const menu = document.querySelector(".header__menu");
const bodt = document.querySelector("body");
const account_text = document.querySelectorAll(".header__account__text");
const nav_links = document.querySelectorAll(".header__nav__link");
burger.addEventListener("click" , () => {
  menu.classList.toggle("active");
  body.classList.toggle("lock-overflow");
  burger.classList.toggle("active");
  account_text.forEach(el => {
    el.classList.toggle("anim_actived");
  });
  nav_links.forEach(el => {
    el.classList.toggle("anim_actived");
  });

});