<?php require "backend/views/components/header.php" ?>
<div class="info_modal">
  <div class="info_modal__content">
    <p class="info_modal__content__text"></p>
    <p class="info_modal__content__close"></p>
  </div>
</div>
<div class="error_modal">
  <div class="error_modal__content">
    <p class="error_modal__content__text"></p>
    <p class="error_modal__content__close"></p>
  </div>
</div>
<div class="wrapper">
  <form action="/register" method="post" class="form">
    <p class="form__p">Логин:</p>
    <input name='login' id='login' class="form__input" type="text" autocomplete="off">
    <p class="form__p">Email:</p>
    <input name='email' id='email' class="form__input" type="text" autocomplete="off">
    <p class="form__p">Пароль:</p>
    <input name='password' id='password' autocomplete="off" class="form__input" type="password">
    <p class="form__p">Повторите пароль:</p>
    <input name='password_repeat' id='password_repeat' autocomplete="off" class="form__input" type="password">
    <input type="hidden" name="security_token" value="<?= $csrf_token ?>">
    <input id="g-recaptcha-response" type="hidden" name="g-recaptcha-response">
    <div class="checker">
      <input type="checkbox" class="checker__custom-checkbox" id="check" name="checker">
      <label for="check"></label>
      <p class="form__p checker__p">Я соглашаюсь c </p>
      <a href="/">Условиями Пользования</a>

    </div>

    <button class="form__button" type="submit">Создать аккаунт</button>
  </form>
</div>
<?php require "backend/views/components/footer.php" ?>
<script src="https://www.google.com/recaptcha/api.js?render=<?= $public_key_recaptha ?>"></script>
<script src="/frontend/js/jquery.min.js"></script>
<script src="/frontend/js/Modal.min.js"></script>
<script src="/frontend/js/SendForm.min.js" defer></script>
<script src="/frontend/js/onscroll.min.js"></script>