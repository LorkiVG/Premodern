<?php 
return [
	'all' => [
		'fpassword',
		'reset',
		'reseting',
		
	],
	'authorize' => [
		'profile',
		'logout',
		'newEmail',
		'getSkin',
		'getActiveSkin',
		'uploadSkin',
		'setActiveSkin',


	],
	'guest' => [
		'register',
		'login',
		'confirm'
	],
	'admin' => [
		//
	],
	'admin_active' => [
		
	]

];
?>