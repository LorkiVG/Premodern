<?php require "backend/views/components/header.php" ?>
<div class="wrapper">
  <div class="content">
    <h1 class="content__title">Технические Работы</h1>
    <p class="content__p">Зайдите немного позже.</p>
  </div>

</div>
<script src="/frontend/js/onscroll.min.js"></script>
<?php require "backend/views/components/footer.php" ?>