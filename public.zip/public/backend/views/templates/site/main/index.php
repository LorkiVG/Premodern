<?php require "backend/views/components/header.php" ?>
<div class="font"></div>
<div class="wrapper">
  <div class="intro">
    <video class="intro__video" poster="/frontend/videos/poster.png" loop muted autoplay>
      <source type="video/webm" src="/frontend/videos/video_trailer.webm">
      <source type="video/mp4" src="/frontend/videos/video_trailer.mp4">
    </video>
    <div class="intro__content">
      <div class="intro__content__logo anim-item always_active">
        <img src="/frontend/img/logo/logo.png" alt="LOGO" class="intro__content__logo__img ">
      </div>
      <div class="intro__content__text">
        <h1 class="intro__content__text__title title_h1 always_active anim-item">PreModern</h1>
      </div>
    </div>
  </div>
  <div class="content">
    <div class="block__2">
      <div class="block__2__chart always_active anim-item">
        <canvas width='900' height='590' class="block__2__chart__canvas"></canvas>
      </div>

      <h1 class="block__2__title title_h1 always_active anim-item">Статистика Онлайн</h1>
    </div>
    <div class="block__3">
      <h1 class="block__3__title title_h1 always_active anim-item">Коротко о сервере</h1>
      <p class="block__3__text always_active anim-item">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vel asperiores molestiae perspiciatis rerum sed fugiat, ipsa labore deleniti deserunt cum. Quasi necessitatibus, similique esse cum magnam dolor minima dignissimos commodi! Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iste neque dolor sapiente voluptas. A voluptatum, aliquid dolores laborum reiciendis provident vitae voluptate quam, aut odio minima officiis illum tenetur reprehenderit omnis ab maiores enim delectus eum. Quam deleniti, accusantium corrupti praesentium vitae repellat labore dolorem sequi quia libero similique? Dolorem.</p>
      <div class="block__3__in_detail always_active anim-item">
        <p>Подробнее посмотреть про изменение крафтов и роли можно в </p><a href="/info">Информация по серверу</a>
      </div>
    </div>
    <div class="block__4">
      <img data-predmatch="800" class="block__4__left_wall always_active anim-item" src="/frontend/img/svg/left_wall.svg" alt="wall">
      <img data-predmatch="800" class="block__4__right_wall always_active anim-item" src="/frontend/img/svg/right_wall.svg" alt="wall">
      <div class="block__4__content">
        <h1 class="block__4__content__title always_active anim-item">Скачать</h1>
        <div class="block__4__content__elements">
          <div class="block__4__content__elements__element always_active anim-item">
            <div class="block__4__content__elements__element__img">
              <img src="/frontend/img/svg/windows.svg" alt="Error_Img">
            </div>
            <a href="/" class="block__4__content__elements__element__button">Windows</a>
          </div>
          <div class="block__4__content__elements__element always_active anim-item">
            <div class="block__4__content__elements__element__img">
              <img src="/frontend/img/svg/linux.svg" alt="Error_Img">
            </div>
            <a href="/" class="block__4__content__elements__element__button">Linux</a>
          </div>
          <div class="block__4__content__elements__element always_active anim-item">
            <div class="block__4__content__elements__element__img">
              <img src="/frontend/img/svg/macos.svg" alt="Error_Img">
            </div>
            <a href="/" class="block__4__content__elements__element__button">MacOS</a>
          </div>
        </div>
      </div>
    </div>
    <?php require "backend/views/components/footer.php" ?>
  </div>
</div>

<script src="/frontend/js/chart.min.js"></script>
<script>
  let chart = document.querySelector(".block__2__chart__canvas");
  let chart_ctx = chart.getContext("2d");
  let chart_view = new Chart(chart_ctx, {
    type: "bar",
    data: {
      labels: ["28.12.20", "29.12.20", "30.12.20", "31.12.20", "01.01.21"],
      datasets: [{
        label: "Кол-во игроков",
        data: [30, 29, 32, 51, 70],
        backgroundColor: "rgba(242,183,5, 0.2)",
        borderColor: "rgba(255, 206, 86, 1)",
        borderWidth: 1
      }]
    },
    options: {
      animation: {
        duration: 2000,
      },
      scales: {
        yAxes: [{
          ticks: {
            beginAtZero: true
          }
        }]
      }
    }
  });
</script>
<script src="/frontend/js/onscroll.min.js"></script>