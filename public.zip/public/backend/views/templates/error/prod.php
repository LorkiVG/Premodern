<?php require "backend/views/components/header.php" ?>
<div class="wrapper">
  <div class="content">
    <h1><?php echo $message;?></h1>
  </div>
</div>
<script src="/frontend/js/onscroll.min.js"></script>
<?php require "backend/views/components/footer.php" ?>