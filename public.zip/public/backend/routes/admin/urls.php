<?php 
return [
  ['admin','admin','index'],
  ['admin/login','admin','login'],
  ['admin/logout', 'admin', 'logout'],
  ['admin/statistic' , 'admin','statistic'],
  ['admin/players' , 'admin','players'],
  ['admin/active' , 'admin','active'],
  ['admin/others', 'admin', 'others'],
  ['admin/players/edit_player', 'admin', 'editPlayer'],
  ['admin/players/get_skin_by_player', 'admin' , 'getSkinByPlayer']
];


