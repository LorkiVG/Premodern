<?php

return [
  'host' => 'smtp.gmail.com',
  'username' => 'premodern.ms@gmail.com',
  'password' => '5df2f3154ef9f960747f2b8515254ef3a1da25',
  'secure' => 'ssl',
  'port' => 465
];