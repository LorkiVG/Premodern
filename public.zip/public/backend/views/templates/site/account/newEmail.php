<?php require "backend/views/components/header.php" ?>
<div class="wrapper">
  <div class="content">
    <h1 class="content__title">Email активирован!</h1>
    <a href="/profile" class="content__button">Перейти в профиль</a>
  </div>

</div>
<script src="/frontend/js/onscroll.min.js"></script>
<?php require "backend/views/components/footer.php" ?>