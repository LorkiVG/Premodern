$('.modal_skins__conteiner').slick({
  infinite: false
});



const skin = document.querySelectorAll("#skin_view");
const button_open_skin = document.querySelector(".open__modal");
const modal_closer = document.querySelector(".modal_skins__close");
const modal_skins = document.querySelector(".modal_skins");
const forms = document.querySelectorAll(".form");
const timeout = 1200;

function createModel(canvas, width, height, skin) {
  return new skinview3d.FXAASkinViewer({
    canvas: canvas,
    width: width,
    height: height,
    skin: skin,
  });
}



function sendRequestFetchGet(url) {
  return fetch(url)
    .then(
      (response) => {
        if (response.ok) {
          return response.json();
        } else {
          return console.error('!ERRoR-- Check Internet Connection --ERRoR!');

        }
      }
    )
    .catch((e) => {
      return console.error('Error' + '-' + e);
    });
}
function sendRequestFetchPost(url, body) {
  return fetch(url, {
    method: 'POST',
    body: JSON.stringify(body),
    headers: {
      'Content-Type': 'application/json'
    }
  })
    .then(
      (response) => {
        if (response.ok) {
          return response.json();
        } else {
          return console.error('--ERRoR!');

        }
      }
    )
    .catch((e) => {
      return console.error('Error' + '-' + e);
    });
}
forms.forEach(element => {
  let num = element.dataset.n;
  let recaptcha = document.querySelector("#g-recaptcha-response_"+num);
  element.addEventListener("submit", e => {
    e.preventDefault();
    grecaptcha.ready(function() {
      grecaptcha
        .execute("6LfbviwaAAAAAKsnSIlrcYjVsYcMRLiAvS0lQc-U", {
          action: "login"
        })
        .then(function(token) {
          recaptcha.value = token;
          let form = new SendForm(element);
          form.send();
        });
    });
  });
});

button_open_skin.addEventListener("click", () => {
  body.classList.add("padding-lock-modal");
  body.setAttribute('style', 'padding-right:' + scrollWidth + 'px');
  modal_skins.classList.add("active");
});
modal_closer.addEventListener("click", () => {
  modal_skins.classList.remove("active");
  body.classList.remove("padding-lock-modal");
  body.setAttribute('style', 'padding-right: 0px;');

});


skin.forEach(el => {
  let num = el.dataset.num;
  let json;
  let response;

  $.ajax({
    type: "GET",
    url: `/admin/players/get_skin_by_player?n=${num}&p=${name_player}`,
    success: function (resp) {
      json = JSON.parse(resp);
      response = json.response;
      let skinViewerInModal;
      if (response != "none" && response != "error") {
        skinViewerInModal = createModel(el, 350, 420, response);
      } else if (response == "none") {
        skinViewerInModal = new skinview3d.FXAASkinViewer({
          canvas: el,
          width: 350,
          height: 520,
        });
        const error = document.createElement("p");
        error.textContent = "Слот пуст :(";
        error.classList.add("skin_none");
        error.classList.add(`skin_none_${num}`);
        el.parentElement.appendChild(error);
      } else {
        skinViewerInModal = new skinview3d.FXAASkinViewer({
          canvas: el,
          width: 350,
          height: 520,
        });
        const error = document.createElement("p");
        error.textContent = "Ошибка :(";
        error.classList.add("skin_none");
        error.classList.add(`skin_none_${num}`);
        el.parentElement.appendChild(error);
      }
      let control = skinview3d.createOrbitControls(skinViewerInModal);
      let walkAnimationSkinInMenu = skinViewerInModal.animations.add(
        skinview3d.WalkingAnimation
      );
      let rotateAnimationSkinInMenu = skinViewerInModal.animations.add(
        skinview3d.RotatingAnimation
      );
      walkAnimationSkinInMenu.speed = 0;
      rotateAnimationSkinInMenu.speed = 0;
      skinViewerInModal.width = 0;
      skinViewerInModal.height = 0;
      modal_closer.addEventListener("click", () => {
        setTimeout(() => {
          walkAnimationSkinInMenu.speed = 0;
          rotateAnimationSkinInMenu.speed = 0;
          skinViewerInModal.width = 0;
          skinViewerInModal.height = 0;
        }, timeout);
      });
      button_open_skin.addEventListener("click", () => {
        walkAnimationSkinInMenu.speed = 1;
        rotateAnimationSkinInMenu.speed = -0.1;
        skinViewerInModal.width = 350;
        skinViewerInModal.height = 520;
      });
    }
  });
});