<?php 
  return $config = [
    'private_key' => '6LeYaCwaAAAAALNK1OqMtUyPd21-SHHSV-XCKeQA',
    'public_key' => '6LfbviwaAAAAAKsnSIlrcYjVsYcMRLiAvS0lQc-U',
  ];
?>