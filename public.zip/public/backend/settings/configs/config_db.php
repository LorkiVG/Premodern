<?php 
  return $config = [
    'host' => 'localhost', 
    'username' => 'root',
    'password' => 'root',
    'db_name' => 'premodern'
  ];











?>