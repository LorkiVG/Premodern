<?php 
  return $config = [
    'password' => '3d002c780fcbf0fa04de1d6d1bb1bd3a5bfac6cddbe8c8fa2be6a55d75be914f5af218227917cfcbbf5c225e92acc18251feb45a382859d109429e11',
  ];
