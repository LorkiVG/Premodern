window.addEventListener("load" , ()=>{
  const wrapper = document.querySelector(".wrapper");
  const font = document.querySelector(".font");
  font.setAttribute('style', 'height:' + (wrapper.clientHeight - 8)+ 'px');
  window.addEventListener("resize", () => {
    wrapperHeight_ = wrapper.clientHeight;
    console.log(wrapperHeight_);
    font.setAttribute('style', 'height:' + wrapperHeight_ + 'px');
  });
});

