<?php 

namespace backend\models\site;

use backend\core\Model;

class Main extends Model {

}

