
$('form').submit(function (e) {
	
	e.preventDefault();
	grecaptcha.ready(function () {
		grecaptcha.execute('6LfbviwaAAAAAKsnSIlrcYjVsYcMRLiAvS0lQc-U', { action: 'login' }).then(function (token) {
			$('#g-recaptcha-response').val(token);
			let form = new SendForm(document.querySelector('form')); 
			form.send();
		});
	});
});
