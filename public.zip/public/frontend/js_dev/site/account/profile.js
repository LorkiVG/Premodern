//!!! СКИНЫ ПУСКАЕМ НА ОТДЕЛЬНЫЙ URL

$('.modal_skins__conteiner').slick({
  infinite: false
});
const button_open_skin = document.querySelector(".content__block_2__element__button");
const modal_closer = document.querySelector(".modal_skins__close");
const modal_skins = document.querySelector(".modal_skins");
const timeout = 1200;
const skin = document.querySelectorAll("#skin_view");
const skin_d_to_input = document.querySelectorAll(".modal_skins__skin__input");
const skin_d_to_preload = document.querySelector("#skin_view__d_to_preload");
const skin_d_preload = document.querySelectorAll("#skin_view_preview");
const skin_view_select_skin = document.querySelectorAll('.skin_view_select_skin');
const skins_recaptcha_responce = document.querySelectorAll("#skin_g-recaptcha-response");

function createModel(canvas, width, height, skin) {
  return new skinview3d.FXAASkinViewer({
    canvas: canvas,
    width: width,
    height: height,
    skin: skin,
  });
}



function sendRequestFetchGet(url) {
  return fetch(url)
    .then(
      (response) => {
        if (response.ok) {
          return response.json();
        } else {
          return console.error('!ERRoR-- Check Internet Connection --ERRoR!');

        }
      }
    )
    .catch((e) => {
      return console.error('Error' + '-' + e);
    });
}
function sendRequestFetchPost(url, body) {
  return fetch(url, {
    method: 'POST',
    body: JSON.stringify(body),
    headers: {
      'Content-Type': 'application/json'
    }
  })
    .then(
      (response) => {
        if (response.ok) {
          return response.json();
        } else {
          return console.error('--ERRoR!');

        }
      }
    )
    .catch((e) => {
      return console.error('Error' + '-' + e);
    });
}
let skinViewer = new skinview3d.FXAASkinViewer({
  canvas: document.getElementById("skin-preview-active"),
  width: 300,
  height: 520,
});
sendRequestFetchGet("/account/get_active_skin").then(
  (res) => {
    skinViewer.loadSkin(res.response);
  }
)

let control = skinview3d.createOrbitControls(skinViewer);
let walkAnimationSkinInMenu = skinViewer.animations.add(skinview3d.WalkingAnimation);
let rotateAnimationSkinInMenu = skinViewer.animations.add(skinview3d.RotatingAnimation);
walkAnimationSkinInMenu.speed = 1;
rotateAnimationSkinInMenu.speed = -0.1;

skin.forEach(el => {
  let num = el.dataset.num;
  let json;
  let response;

  $.ajax({
    type: "GET",
    url: `/account/get_skin?n=${num}`,
    success: function (resp) {
      json = JSON.parse(resp);
      response = json.response;
      let skinViewerInModal;
      if (response != "none" && response != "error") {
        skinViewerInModal = createModel(el, 350, 420, response);
      } else if (response == "none") {
        skinViewerInModal = new skinview3d.FXAASkinViewer({
          canvas: el,
          width: 350,
          height: 420,
        });
        const error = document.createElement("p");
        error.textContent = "Слот пуст :(";
        error.classList.add("skin_none");
        error.classList.add(`skin_none_${num}`);
        el.parentElement.appendChild(error);
      } else {
        skinViewerInModal = new skinview3d.FXAASkinViewer({
          canvas: el,
          width: 350,
          height: 420,
        });
        const error = document.createElement("p");
        error.textContent = "Ошибка :(";
        error.classList.add("skin_none");
        error.classList.add(`skin_none_${num}`);
        el.parentElement.appendChild(error);
      }
      let control = skinview3d.createOrbitControls(skinViewerInModal);
      let walkAnimationSkinInMenu = skinViewerInModal.animations.add(
        skinview3d.WalkingAnimation
      );
      let rotateAnimationSkinInMenu = skinViewerInModal.animations.add(
        skinview3d.RotatingAnimation
      );
      walkAnimationSkinInMenu.speed = 0;
      rotateAnimationSkinInMenu.speed = 0;
      skinViewerInModal.width = 0;
      skinViewerInModal.height = 0;
      modal_closer.addEventListener("click", () => {
        setTimeout(() => {
          walkAnimationSkinInMenu.speed = 0;
          rotateAnimationSkinInMenu.speed = 0;
          skinViewerInModal.width = 0;
          skinViewerInModal.height = 0;
        }, timeout);
      });
      button_open_skin.addEventListener("click", () => {
        walkAnimationSkinInMenu.speed = 1;
        rotateAnimationSkinInMenu.speed = -0.1;
        skinViewerInModal.width = 350;
        skinViewerInModal.height = 420;
      });
      let modal = document.querySelector(".error_modal");
      let modal__content = document.querySelector(".error_modal__content");
      let modal__closer = document.querySelector(
        ".error_modal__content__close"
      );
      let modal__text = document.querySelector(
        ".error_modal__content__text"
      );
      let elements_lock_padding = document.querySelectorAll(
        "padding_lock_element"
      );
      let window_dialog = new ModalDialogSwitch(
        modal,
        modal__content,
        modal__closer,
        elements_lock_padding
      );
      let skin_to_server = document.querySelector(`.skin_view__d_to_server_${el.dataset.num}`);
      skin_to_server.addEventListener("click", event => {
        event.preventDefault();
        let skin_input = document.querySelector(
          `#skin_view_d_input_${el.dataset.num}`
        );
        let form = skin_input.parentElement;
        if (skin_input.files[0] !== undefined) {
          grecaptcha.ready(function () {
            grecaptcha
              .execute("6LfbviwaAAAAAKsnSIlrcYjVsYcMRLiAvS0lQc-U", {
                action: "login"
              })
              .then(function (token) {
                skins_recaptcha_responce.forEach(elem => {
                  if (elem.dataset.num == skin_input.dataset.num) {
                    elem.value = token;
                    let formD = new SendForm(form);
                    let formDat = new FormData(form);
                    formDat.append("skin_texture", skin_input.files[0]);
                    formD.send(formDat).then((res) => {
                      if (res.status == 'success') {
                        sendRequestFetchGet(
                          `/account/get_skin?n=${elem.dataset.num}`
                        ).then(reso => {
                          skinViewerInModal.loadSkin(reso.response);
                          if (document.querySelector(`.skin_none_${num}`)) {
                            let skin_none = document.querySelector(`.skin_none_${num}`);
                            skin_none.parentElement.removeChild(skin_none);
                          }
                          let input = document.querySelector(`#skin_view_d_input_${num}`);
                          let preload = document.querySelector(`.skin_view_preview_${num}`);
                          input.files[0] = null;
                          let img = preload.children[0];
                          preload.removeChild(img);
                          sendRequestFetchGet("/account/get_active_skin").then(
                            (r) => {
                              skinViewer.loadSkin(r.response);
                            }
                          )
                        });
                      } else {
                        console.log(res);
                      }
                      
                    })
                  } else {
                    return;
                  }
                });
              });
          });
        } else {
          modal__text.textContent = "Скин не выбран для данного слота";
          window_dialog.activateDialog(300, 100, "padding-lock-modal");
        }
      });
    }
  });
});

skin_view_select_skin.forEach(elem => {
  elem.addEventListener("click" , (evt) => {
    evt.preventDefault();
    let num = elem.dataset.num;
    let form = elem.parentElement;
    grecaptcha.ready(function () {
      grecaptcha
        .execute("6LfbviwaAAAAAKsnSIlrcYjVsYcMRLiAvS0lQc-U", {
          action: "login"
        })
        .then(function (token) {
          skins_active_recaptcha_responce = document.querySelectorAll("#skin_active_g-recaptcha-response");
          skins_active_recaptcha_responce.forEach(el => {
            if (elem.dataset.num == el.dataset.num) {
              el.value = token;
              let formD = new SendForm(form);
              formD.send().then((res) => {
                if (res.status == 'success') {
                  sendRequestFetchGet(
                    `/account/get_active_skin`
                  ).then(reso => {
                    skinViewer.loadSkin(reso.response);
                  });
                } else {
                  console.log(res);
                }
              })
              
            } else {
              return;
            }
          });
        });
    });
    
  });
});

skin_d_to_input.forEach(elm => {
  elm.addEventListener("change", evt => {
    let f = evt.target.files[0];
    let modal = document.querySelector(".error_modal");
    let modal__content = document.querySelector(".error_modal__content");
    let modal__closer = document.querySelector(
      ".error_modal__content__close"
    );
    let modal__text = document.querySelector(".error_modal__content__text");
    let elements_lock_padding = document.querySelectorAll(
      "padding_lock_element"
    );
    let window_dialog = new ModalDialogSwitch(
      modal,
      modal__content,
      modal__closer,
      elements_lock_padding
    );
    if (f.type.match("image.png")) {
      let reader = new FileReader();
      let shown = true;

      reader.onload = (function (theFile) {
        return function (e) {
          let img = new Image();
          img.onerror = function () {
            modal__text.textContent = "Неккоректный файл скина.";
            window_dialog = new ModalDialogSwitch(
              modal,
              modal__content,
              modal__closer,
              elements_lock_padding
            );
            window_dialog.activateDialog(300, 100, "padding-lock-modal");
          };
          img.onload = async function () {
            let allowedSizes = [];
            let standartSizes = ["64x32", "64x64"];
            let allSizes = [
              ...standartSizes,
              "128x64",
              "256x128",
              "512x256",
              "1024x512",
              "2048x1024",
              "4096x2048"
            ];

            let currentSize = this.width + "x" + this.height;
            let canUseHD = false;
            if (canUseHD) {
              allowedSizes = allSizes;
            } else {
              allowedSizes = standartSizes;
            }

            if (allowedSizes.includes(currentSize)) {
              //*СОЗДАЕМ елемент картинки для предлоадинга
              //!Скины на отдельный url
              let skin_preload = document.querySelector(`.skin_view_preview_${elm.dataset.num}`);
              if (skin_preload.children.length == 0) {
                img.classList.add(
                  "modal_skins__skin__preview_skin__skin"
                );
                skin_preload.appendChild(img);
              } else {
                modal__text.textContent = "Скин уже загружен на данный слот";
                window_dialog.activateDialog(
                  300,
                  100,
                  "padding-lock-modal"
                );
              }
            } else {
              if (allSizes.includes(currentSize)) {
                modal__text.textContent =
                  "На нашем сервере запрещены HD-скины.";
                window_dialog.activateDialog(300, 100, "padding-lock-modal");
              } else {
                modal__text.textContent = "Неккоректная картинка скина.";
                window_dialog.activateDialog(300, 100, "padding-lock-modal");
              }
            }
          };
          img.src = e.target.result;
        };
      })(f);
      reader.readAsDataURL(f);
    } else {
      modal__text.textContent = "Неккоректный файл скина.";
      window_dialog.activateDialog(300, 100, "padding-lock-modal");
    }
  });
});


//*Можно попробовать сразу при переборе массива skin сразу объявлять переменные которые сходятся по data-num атребуту
button_open_skin.addEventListener("click", () => {
  body.classList.add("padding-lock-modal");
  body.setAttribute('style', 'padding-right:' + scrollWidth + 'px');
  modal_skins.classList.add("active");
  setTimeout(() => {
    walkAnimationSkinInMenu.speed = 0;
    rotateAnimationSkinInMenu.speed = 0;
    skinViewer.width = 0;
    skinViewer.height = 0;
  }, timeout);
});
modal_closer.addEventListener("click", () => {
  modal_skins.classList.remove("active");
  body.classList.remove("padding-lock-modal");
  body.setAttribute('style', 'padding-right: 0px;');
  walkAnimationSkinInMenu.speed = 1;
  rotateAnimationSkinInMenu.speed = -0.1;
  skinViewer.width = 300;
  skinViewer.height = 520;

});

$('#general_settings').submit(function (e) {
  e.preventDefault();
  grecaptcha.ready(function () {
    grecaptcha.execute('6LfbviwaAAAAAKsnSIlrcYjVsYcMRLiAvS0lQc-U', { action: 'login' }).then(function (token) {
      $('#general_settings_g-recaptcha-response').val(token);
      let form = new SendForm(document.querySelector('#general_settings'));
      form.send();
    });
  });
});

$('#password_settings').submit(function (e) {

  e.preventDefault();
  grecaptcha.ready(function () {
    grecaptcha.execute('6LfbviwaAAAAAKsnSIlrcYjVsYcMRLiAvS0lQc-U', { action: 'login' }).then(function (token) {
      $('#password_settings_g-recaptcha-response').val(token);
      let form = new SendForm(document.querySelector('#password_settings'));
      form.send();
    });
  });
});


