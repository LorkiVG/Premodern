
<header class="header lock_padding">
  <a href = "/" class="header__logo">
    <img src="/frontend/img/logo/logo_mini.png" alt="LOGO" class="header__logo__img old">    
  </a>
  <div class="header__menu">
    <nav class="header__nav">
      <a href="/helpme" class="header__nav__link old">Поддержка</a>
      <a href="/info" class="header__nav__link old">О сервере</a>
      <a href="/donate" class="header__nav__link old">Помощь Проекту</a>
    </nav>
    <div class="header__account">
      <a href="/login" class="header__account__text old">Вход</a>
      <a href="/register" class="header__account__text old">Регистрация</a>
    </div>
  </div>
  <div class="header__burger">
    <div class="header__burger__lines"></div>
  </div>
  
</header>