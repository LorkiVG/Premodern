<?php 
/*
  Name Project: PreModern
  Code: Lorki
  Desing: Lorki, Holesmak , WintressB
  Server-Core: Lorki-Engine v0.8 beta
*/
require 'backend/core/ErrorHandler.php';

require 'backend/settings/settings.php';
require 'backend/settings/configs/config.php';

use backend\lib\UserAgent;

if ($settings['PROJECT_UPDATED']) {
  $style = '/frontend/css/update_theme.min.css';
  ob_start();
  require "backend/views/templates/update/update_theme.php";
  $view = ob_get_clean();
  
  require 'backend/views/layouts/default.php';
  exit;
  
}

new ErrorHandler($settings,$config);
if ($settings['DEBUG_MODE'] and $settings['DEV_TOLLS']) {
  require 'backend/framework/FastDebug.php';
}
$apps = require 'backend/apps/apps.php';
use backend\core\Router;

spl_autoload_register(function($class){
  $path = str_replace('\\','/',$class.'.php');
  if (file_exists($path)) {
    require $path;
  }
});
session_start();
$user_agent = UserAgent::parseUserAgent();
if ($user_agent['name'] == "Internet Explorer") {
  $style = '/frontend/css/old_theme.min.css';
  ob_start();
  require "backend/views/templates/old_browser.php";
  $view = ob_get_clean();

  require 'backend/views/layouts/old_browsers.php';
  exit;
}

if (empty($_SESSION['authorize']['is_admin'])) {
  $_SESSION['authorize']['is_admin'] = 0;
}


$router = new Router($apps, $config);