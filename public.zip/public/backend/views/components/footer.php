<footer class = "footer">
  <div class="footer__content">
    <div class="footer__content__text">
      <a href = "/" class="footer__content__text__title always_active anim-item">PreModern</a>
      <p class="footer__content__text__copyright always_active anim-item">© 2020 PreModern</p>
    </div>
    <div class="footer__content__author">
      <p class="footer__content__author__text anim-item">WebSite created by <a href="">Lorki</a></p>
    </div>
  </div>
</footer>