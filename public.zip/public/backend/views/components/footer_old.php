<footer class = "footer">
  <div class="footer__content">
    <div class="footer__content__text">
      <a href = "/" class="footer__content__text__title old">PreModern</a>
      <p class="footer__content__text__copyright old">© 2020 PreModern</p>
    </div>
    <div class="footer__content__author">
      <p class="footer__content__author__text old">WebSite created by <a class = "old" href="">Lorki</a></p>
    </div>
  </div>
</footer>