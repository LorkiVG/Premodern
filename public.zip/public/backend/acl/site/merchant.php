<?php 
return [
	'all' => [
    'donate',
	],
	'authorize' => [
		//
	],
	'guest' => [
		
	],
	'admin' => [
		//
	],
	'admin_active' => [
		
	]

];
