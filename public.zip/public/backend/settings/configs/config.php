<?php 


$config = [
  'PROJECT_NAME' => 'PreModern',
  'PROJECT_NAME_IN_ADMIN' => 'Admin Panel',
];


?>