<?php require "backend/views/components/header.php" ?>
<div class="wrapper">
  <div class="content">
    <h1 class = "content__title">Аккаунт активирован!</h1>
    <a href = "/login" class = "content__button">Перейти ко входу</a>
  </div>
  
</div>
<script src="/frontend/js/onscroll.min.js"></script>
<?php require "backend/views/components/footer.php" ?>