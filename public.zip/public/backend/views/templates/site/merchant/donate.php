<?php require "backend/views/components/header.php" ?>
<div class="wrapper">

  <div class="content">
    <div class="content__title anim-item always_active ">Спасибо за вашу поддержку!</div>
    <p style = "font-size:44px" class="content__title anim-item always_active ">Выберите любой удобный способ оплаты</p>
    <div class="content__elements">
      <a href="/donate/payeer" target="_blank">
        <div class="content__elements__element anim-item always_active">
          <img src="/frontend/img/merchant/payeer.png" alt="Discord">
        </div>
      </a>
      <a href="/donate/requisites" target="_blank">
        <div class="content__elements__element anim-item always_active">
          <img src="/frontend/img/merchant/requisites.svg" alt="Telegram">
        </div>
      </a>
    </div>
  </div>
</div>
<script src="/frontend/js/onscroll.min.js"></script>
<?php require "backend/views/components/footer.php" ?>