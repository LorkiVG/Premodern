let body = document.querySelector('body');
let lock_padding = document.querySelectorAll(".lock_padding");
let scrollWidth = window.innerWidth - body.clientWidth;
lock_padding.forEach(lock_padding_element => {
  lock_padding_element.setAttribute('style', 'padding-right:' + scrollWidth + 'px');
});
body.setAttribute('style', 'padding-right:' + scrollWidth + 'px;overflow: hidden;');



let 
  preloader = document.querySelector('.preloader'),
  progress_bar = document.querySelector('.preloader__progress_bar'),
  progress = progress_bar.children[0],
  images = document.querySelectorAll('img'),
  videos = document.querySelectorAll('video'),
  images_count = images.length,
  videos_count = videos.length,
  onload = 1;
  total_count = images_count + videos_count + onload,
  onload_load = 0;
  images_loaded_count = 0,
  videos_loaded_count = 0,
  total_loaded_count = 0;

progress_bar.dataset.progress = 0;

if (videos.lenght !== 0 && images.lenght !== 0) {
  imgAndVideo(images,videos);
} else if (images.lenght !== 0) {
  imgAndVideo(images,null);
} else {
  imgAndVideo(null, videos);
}


function imgAndVideo(images,videos){
  
  if (images !== null && images_loaded_count <= images_count) {
    
    for (let i = 0; i < images_count; i++) {
      
      image_clone = new Image();
      images_loaded_count++;
      
      image_clone.onload = playingProgress;
      image_clone.onerror = playingProgress;
      image_clone.src = images[i].src;
      
    }
  }
  
  if (videos !== null && videos_loaded_count <= videos_count) {
    for (let i = 0; i < videos_count; i++) {
      const video = videos[i] ;
      var b = setInterval(() => {
        if (video.readyState == 4) {
          playingProgress();
          clearInterval(b);
        }
      }, 500);
    }
  }
  if (onload_load < 1) {
    var a = setInterval(() => {
      onload_load++;
      if (document.readyState === "complete") {

        playingProgress();
        clearInterval(a);
      }
    }, 200);

  }
  
}
function playingProgress() {
  
  total_loaded_count++;
  percent = (((100 / total_count) * total_loaded_count) << 0)
  progress_bar.dataset.progress = percent;
  progress.setAttribute('style', `width:${percent}%;`);
  
  if (total_count == total_loaded_count) {
    setTimeout(() => {
      if (!preloader.classList.contains('done')) {
        preloader.classList.add('done');
        setTimeout(() => {
          
          body.setAttribute('style', 'padding-right:' + 0 + 'px;overflow: visibly');
          lock_padding.forEach(lock_padding_element => {
            lock_padding_element.setAttribute('style', 'padding-right:' + 0 + 'px');
          });

        }, 1000);
        
        
      }
    }, 1700);
  }
}