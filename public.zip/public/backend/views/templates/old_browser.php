<?php require "backend/views/components/header_old.php" ?>
<div class="wrapper">
  <div class="content">
    <h1 class="content__title">Ваш браузер устарел.</h1>
  </div>

</div>
<script src="/frontend/js/onscroll.min.js"></script>
<?php require "backend/views/components/footer_old.php" ?>