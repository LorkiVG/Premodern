<?php 
return [
	'all' => [
		'index',
		'help'
	],
	'authorize' => [
		//
	],
	'guest' => [
		
	],
	'admin' => [
		//
	],
	'admin_active' => [
		
	]

];
?>