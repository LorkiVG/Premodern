const input = document.querySelector("#input_set");
const button = document.querySelector("#input_button");
button.addEventListener("click", () => {
  let val = input.value;
  if (val == "") {
    window.location.href = '/admin/players';
  } else {
    window.location.href = '/admin/players?player=' + val;
  }
});

