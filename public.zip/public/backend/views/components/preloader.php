<div class="preloader">
  <img src="/frontend/img/logo/logo.png" alt="">
  <div data-progress = '0' class="preloader__progress_bar">
    <div class="preloader__progress_bar__div"></div>
  </div>
</div>