<?php require "backend/views/components/header_admin.php" ?>
<div class="wrapper">
  <div class="content">
    <h1 class="content__title">Пока ещё не придумал :(</h1>
  </div>

</div>
<script src="/frontend/js/onscroll.min.js"></script>
<?php require "backend/views/components/footer.php" ?>