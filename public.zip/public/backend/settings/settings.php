<?php 
$settings = [
  'DEBUG_MODE' => false,
  'DEV_TOLLS' => true,

  'PROJECT_UPDATED' => false,
  
  'HELPER_ERRORS' => true,

  'DATABASE_USEGE' => true,
  'PDO_FETCH_METHOD' => PDO::FETCH_ASSOC,

];


?>