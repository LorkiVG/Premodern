<?php 

return array (
  ['','main','index'],
  ['helpme','main','help'],
  ['donate', 'merchant', 'donate'],
  ['login','account','login'],
  ['register', 'account','register'],
  ['profile', 'account','profile'],
  ['fpassword', 'account','fpassword'],
  ['logout', 'account','logout'],
  ['account/confirm', 'account' ,'confirm'],
  ['account/new_email', 'account', 'newEmail'],
  ['account/reset', 'account' ,'reset'],
  ['account/reset/ajax', 'account', 'reseting'],
  ['account/get_skin', 'account', 'getSkin'],
  ['account/get_active_skin', 'account', 'getActiveSkin'],
  ['upload_skin', 'account', 'uploadSkin'],
  ['account/set_active_skin', 'account', 'setActiveSkin'],
  
);