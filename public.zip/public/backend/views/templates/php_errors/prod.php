
<?php require "backend/views/components/header.php" ?>
<div class="wrapper">
  <div class="content">
    <h1 class = "title">Произошла неизвестная ошибка.</h1>
  </div>
  
</div>
<script src="/frontend/js/onscroll.min.js"></script>
<?php require "backend/views/components/footer.php" ?>
