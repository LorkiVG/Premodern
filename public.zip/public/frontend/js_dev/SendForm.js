class SendForm {
  constructor (form) {
    this.form = form;
  }
  sendFormFetch(url, body, method, headers = {"Content-Type": "application/json"}) {
    let modal;
    let modal__content;
    let modal__closer;
    let elements_lock_padding;
    let window_dialog;
    return fetch(url, {
      method: method,
      body: body,
    
    }).then(
        (response) => {
          if (response.ok) {
            return response.json();
          } else {
            console.error("Response error code");
            $('.error_modal__content__text').text('Произошла неизвестная ошибка, попробуйте ещё раз или обратититесь в Поддержку');
            modal = document.querySelector('.error_modal');
            modal__content = document.querySelector('.error_modal__content');
            modal__closer = document.querySelector('.error_modal__content__close');
            elements_lock_padding = document.querySelectorAll('padding_lock_element');
            window_dialog = new ModalDialogSwitch(modal, modal__content, modal__closer, elements_lock_padding);
            window_dialog.activateDialog(300, 100, 'padding-lock-modal');

          }
        }
      )
      .catch((e) => {
        console.error(e);
        $('.error_modal__content__text').text('Произошла неизвестная ошибка, попробуйте ещё раз или обратититесь в Поддержку');
        modal = document.querySelector('.error_modal');
        modal__content = document.querySelector('.error_modal__content');
        modal__closer = document.querySelector('.error_modal__content__close');
        elements_lock_padding = document.querySelectorAll('padding_lock_element');
        window_dialog = new ModalDialogSwitch(modal, modal__content, modal__closer, elements_lock_padding);
        window_dialog.activateDialog(300, 100, 'padding-lock-modal');
      });
  }
  send(form_data = new FormData(this.form)) {
    let modal;
    let modal__content;
    let modal__closer;
    let elements_lock_padding;
    let window_dialog;
    let headers;
    let result = this.sendFormFetch(this.form.getAttribute('action'), form_data, this.form.getAttribute('method'),headers)
    .then((result) => {
      if (result.url) {
        window.location.href = '/' + result.url;
      } else {
        if (result.status == 'success') {
          $('.info_modal__content__text').text(result.message);
          modal = document.querySelector('.info_modal');
          modal__content = document.querySelector('.info_modal__content');
          modal__closer = document.querySelector('.info_modal__content__close');
          elements_lock_padding = document.querySelectorAll('padding_lock_element');
          window_dialog = new ModalDialogSwitch(modal, modal__content, modal__closer, elements_lock_padding);
          window_dialog.activateDialog(300, 100, 'padding-lock-modal');
          return result;
        } else {
          $('.error_modal__content__text').text(result.message);
          modal = document.querySelector('.error_modal');
          modal__content = document.querySelector('.error_modal__content');
          modal__closer = document.querySelector('.error_modal__content__close');
          elements_lock_padding = document.querySelectorAll('padding_lock_element');
          window_dialog = new ModalDialogSwitch(modal, modal__content, modal__closer, elements_lock_padding);
          window_dialog.activateDialog(300, 100, 'padding-lock-modal');
          return result;
        }
      }
    }).catch ((e) => { 
      $('.error_modal__content__text').text("Произошла неизвестная ошибка, попробуйте ещё раз или обратититесь в Поддержку");
      console.error(e);
      modal = document.querySelector('.error_modal');
      modal__content = document.querySelector('.error_modal__content');
      modal__closer = document.querySelector('.error_modal__content__close');
      elements_lock_padding = document.querySelectorAll('padding_lock_element');
      window_dialog = new ModalDialogSwitch(modal, modal__content, modal__closer, elements_lock_padding);
      window_dialog.activateDialog(300, 100, 'padding-lock-modal');
      return e;
    })
    return result;
  }
}